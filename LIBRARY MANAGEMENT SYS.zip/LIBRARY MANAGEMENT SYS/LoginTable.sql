create table logintable(
id int NOT NULL IDENTITY(1,1) primary key,
username varchar(150) not null,
pass varchar(150) not null
)

insert into logintable (username,pass) values('abdul','pass');

select * from logintable