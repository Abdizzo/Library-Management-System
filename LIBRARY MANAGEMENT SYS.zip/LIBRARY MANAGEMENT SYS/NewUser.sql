create table NewStudent(
stuid int NOT NULL IDENTITY(1,1) primary key,
sname varchar(250) not null,
enroll varchar(250) not null,
dep varchar(250) not null,
contact bigint not null,
email varchar(250) not null
)

sname,enroll,dep,contact,email

select * from NewStudent