﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class AddBooks : Form
    {
        public AddBooks()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtbookname.Text != "" && txtbookauthor.Text != "" && txtbookpublication.Text != "" && txtbookprice.Text != "" && txtbookquantity.Text != "")
            {
                string bname = txtbookname.Text;
                string bauthor = txtbookauthor.Text;
                string bpublication = txtbookpublication.Text;
                Int64 bprice = Int64.Parse(txtbookprice.Text);
                Int64 bquan = Int64.Parse(txtbookquantity.Text);
                string pdate = dateTimePicker1.Text;

                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source = ABDIZZO\\SQLEXPRESS02; database = library;integrated security = True";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                con.Open();
                cmd.CommandText = "insert into NewBook (bName,bAuthor,bPubl,bPDate,bPrice,bQuan) values ('" + bname + "','" + bauthor + "','" + bpublication + "','" + pdate + "'," + bprice + "," + bquan + ")";
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Data Saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtbookname.Clear();
                txtbookauthor.Clear();
                txtbookpublication.Clear();
                txtbookquantity.Clear();
                txtbookprice.Clear();
            }
            else
            {
                MessageBox.Show("empty field NOT allowed", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);


            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("are you sure? This will DELETE your unsaved DATA.","Are you sure?",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)==DialogResult.OK)
            {
                this.Close();
            }

            
        }
    }
}
