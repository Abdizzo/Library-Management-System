﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)

            {
                Application.Exit();
            }

            
        }

        private void addBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBooks abs = new AddBooks();
            abs.Show(); 
        }

        private void viewBookInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewBook vb = new ViewBook();
            vb.Show();
        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUser ast = new AddUser();

            ast.Show();
        }

        private void viewUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewUserInformation vsi = new ViewUserInformation();
            vsi.Show();

        }

        private void issueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //creating an object 
            IssueBooks ib = new IssueBooks();
            ib.Show();
        }

        private void returnBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReturnBook rb = new ReturnBook();
            rb.Show();
        }

        private void checkOutBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookDetails bd = new BookDetails();
            bd.Show();
        }
    }
}
